	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			
<li><a href="#"><i class="fa fa-files-o"></i>Iteam</a>
<ul>
<li><a href="create-iteam.php">Create Iteam</a></li>
<li><a href="manage-iteams.php">Manage Iteam</a></li>
</ul>
</li>


<li><a href="#"><i class="fa fa-car"></i>Requisition</a>
					<ul>
						<li><a href="RequisitionList.php">Requisition By</a></li>
						<li><a href="ManageRequisitionList.php">Manage Requisition</a></li>
					</ul>
				</li>

				<li><a href="#"><i class="fa fa-files-o"></i>Purchase</a>
					<ul>
						<li><a href="PurchaseList.php">Purchase By</a></li>
						<li><a href="ManagePurchaseList.php">Manage Purchase</a></li>
					</ul>
				</li>
			 	<li><a href="WorkOrderList.php"><i class="fa fa-files-o"></i>All Purchase Order</a>
					
				</li>




		

			
				
				<li><a href="#"><i class="fa fa-files-o"></i>Customer</a>
					<ul>
						<li><a href="create-Customer.php">Create Customer</a></li>
						<li><a href="manage-customer.php">Manage Customer</a></li>
					</ul>
				</li>

					<li><a href="#"><i class="fa fa-files-o"></i>Order Details</a>
					<ul>
						<li><a href="Orderdetailsadd.php">Add Information</a></li>
						<li><a href="ManageOrderdetails.php">Manage Information</a></li>
						<li><a href="dailyproduction.php">Daily Prodduction</a></li>
						<li><a href="#">Delivery & Installation</a>
                           <ul>
						     <li><a href="Delivery.php">Add  Delivery  </a></li>
						     <li><a href="Manage_dlvry.php">Manage Delivery</a></li>

						     <li><a href="Installation.php">Add Installation</a></li>
						      <li><a href="Manage_install.php">Manage Installation</a></li>
					       </ul>
						</li>
					</ul>
				</li>
				
				<li><a href="ShowDailyproduction.php"><i class="fa fa-files-o"></i>Daily</a>
					
				</li>

				<li><a href="Deliver&install_list.php"><i class="fa fa-files-o"></i>All Delivery Order</a>
					
				</li>

				
				
		
		

			</ul>
		</nav>