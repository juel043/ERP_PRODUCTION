<?php



$connect = new PDO("mysql:host=localhost;dbname=thesis_car", "root", "");

$data = array(
 ':ordercustomer'  => $_POST["ordercustomer"],
 ':dates'  => $_POST["dates"],
 ':Weight'  => $_POST["Weight"]
); 

$query = "
 INSERT INTO tbl_production 
(ordercustomer,dates,Weight) 
VALUES (:ordercustomer,:dates, :Weight)
";

$statement = $connect->prepare($query);

if($statement->execute($data))
{
 $output = array(
  'ordercustomer' => $_POST['ordercustomer'],
  'dates' => $_POST['dates'],
  'Weight'  => $_POST['Weight']
 );

 echo json_encode($output);
}

?>


